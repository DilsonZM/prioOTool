window.PRIO_FIREBASE_CONFIG = {
  apiKey: 'AIzaSyBHspARYHlx6GdPz7PKI6Ig_w9rL5tveMI',
  authDomain: 'priootool.firebaseapp.com',
  projectId: 'priootool',
  storageBucket: 'priootool.firebasestorage.app',
  messagingSenderId: '886571452258',
  appId: '1:886571452258:web:f70f55df100a62ee634e3b',
  measurementId: 'G-T65CQ9D0BM'
};
